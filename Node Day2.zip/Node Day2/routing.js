var http= require('http');

var url= require('url');

var querystring= require('querystring');



http.createServer
(
	function(req,res)
	{
		if(req.url=='/')
		{
			res.end("Welcome to the Home page");
		}
		else if(req.url=='/login')
		{
			res.writeHead(200,{"Content-Type":"text/html"});
			res.end("<form action='/user' method='post'>  Enter Your Name: <input type='text' name='uid' value=''/> </br> Enter Email ID: <input type='text' name='eid' value=''/></br><input type='submit' name='login' value='Login' /></form>");
		}
		else if(req.url=='/user')
		{
			var urlstring='';
			
			req.on('data',function(chunk)
							{
								urlstring+=chunk;
							}
					);
			req.on('end', function(){

					var qs = querystring.parse(urlstring);
					var name = qs['uid'];
					var email = qs['eid'];
					res.writeHead(200,{"Content-Type":"text/html"});
					res.write(" U r " + name + " and ur email id is :" + email);
					res.end();
					});
		}
		else
		{
			res.writeHead(404,{"Content-Type":"text/html"});
			res.end("Page not found");
		}
		
		
	}
).listen(4000);
console.log("Server started");
